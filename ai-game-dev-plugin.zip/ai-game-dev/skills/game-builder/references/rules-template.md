# CLAUDE.md template

Written at T2.1. Adapt to the project — do not paste verbatim without filling the brackets.

Keep it specific and short. A vague rules file is worse than none, because it creates false confidence. If an entry is a multi-step procedure or only matters in one part of the codebase, move it to a skill or a path-scoped rule in `.claude/rules/` instead of bloating this file.

```markdown
# Project: [game name]

## What this is
Browser game, Three.js. Core loop: [one sentence].
Art direction: [three words].

## Hard constraints
- Playable within ~2 seconds. No loading screen, no login, no downloads.
- Must run on mobile Safari and Android Chrome at 30fps minimum.
- Every tunable value lives in src/core/Constants.js and is exposed in the
  debug panel. Never hardcode a magic number in gameplay code.

## Architecture
src/core/       EventBus, GameState, Constants
src/entities/   player, items, NPCs
src/systems/    physics, spawning, particles
src/scenes/     [list scenes]
src/editor/     SEPARATE. Never modify game code to fix the editor,
                and never modify editor code while working on the game.

- All cross-module communication goes through EventBus.
  No direct imports between entities.
- GameState has a reset() that fully restores a clean start.

## Performance rules
- Repeated objects use InstancedMesh or BatchedMesh, never many individual Mesh objects.
- Dispose geometries, materials, textures and render targets when removing objects.
- Draw call budget: under ~100 per frame on mobile.
- Compress geometry and textures before shipping.
- Reduce geometry segment counts on mobile — it is usually invisible and cheap.

## Working style
- Before implementing anything non-trivial, interview me until the spec is unambiguous.
- Write the plan to plans/<task-id>-<name>.md and wait for approval before coding.
- Small increments. I test every one.
- Update GAME-PROGRESS.md at the end of every task.

## Jam rules (if entering a competition)
[Paste the competition rules here verbatim. Breaking them means
disqualification, so they belong in context every session.]
```

## Verifying it works (T2.4)

Start a fresh session and ask the agent to state the project's hard constraints. If it answers from the file, the rules are loading. If it guesses, the file is in the wrong place or too long to be read reliably.

## When to split into .claude/rules/

Once CLAUDE.md grows past a page, move topic-specific guidance into separate rule files. Path-scoped rules only load when relevant, which keeps the always-on context small. Keep in CLAUDE.md only what should be true in every single session.

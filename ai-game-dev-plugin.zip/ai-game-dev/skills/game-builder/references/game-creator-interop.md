# Using game-creator alongside this process

`game-creator` (PlayableIntelligence, MIT) is installed as a companion library. It is not a competitor to this process — it supplies knowledge, templates and test tooling, while this plugin supplies sequencing and gates.

Read this when the user has game-creator installed and you need to decide whether to draw on it.

## The dividing line

game-creator ships two kinds of thing, and they are treated completely differently.

**Reference skills — use freely.** These load passively when relevant and are pure knowledge. They make generated Three.js code better and reinforce the rules file rather than fighting it.

| Skill | Use it at |
|---|---|
| `threejs-game` | Any code task from P3 onward — event-driven Three.js patterns |
| `game-architecture` | T2.2, and any time module boundaries are in question |
| `game-designer` | P8 — particles, screen shake, transitions, juice |
| `game-qa` | P10 — Playwright gameplay, visual regression, performance |
| `game-deploy` | T0.2 and T11.3 — deployment targets |

**Orchestration — never invoke.** `/viral-game`, `/make-game`, the autonomous `game-creator` agent, and the `game-creator`/`game-qa-runner`/`game-deploy` agents run multi-step pipelines with no user confirmation between steps. That is the precise opposite of a gated ledger. If the user asks for one of these, explain that it would skip the gates they asked for, and offer the equivalent single task instead.

## Assets worth borrowing directly

These are files, not workflows, so they carry no orchestration risk. Copy them into the project rather than invoking the commands that generate them.

**`templates/threejs-3d/`** — a runnable Vite + Three.js starter with the EventBus / GameState / Constants architecture already wired, an input system covering touch and keyboard, and HTML overlays. At **T3.1**, copying this beats scaffolding from scratch: it starts the project already compliant with the rules file, since the architecture in `references/rules-template.md` was derived from this same structure.

**`scripts/validate-architecture.mjs`** — checks EventBus/GameState/Constants compliance and flags magic numbers. Wire this into the project at **T2.4** as the objective test that the rules are actually holding, rather than trusting that they are.

**`scripts/verify-runtime.mjs`** — headless runtime check for WebGL errors and uncaught exceptions. Useful as evidence at any task where "it works" needs to mean more than "it loaded on my machine".

**`scripts/iterate-client.js`** — replays scripted actions and captures screenshots. Genuinely useful at **T10.4** and for regression checking after the polish pass.

**`examples/`** — eight complete games, four of them Three.js. Reading `flight-simulator` or `labyrinth` is often faster than asking for an explanation of how a pattern is meant to work.

**`render_game_to_text()`** — their convention of exposing current game state as JSON on `window`. Worth adopting early: it lets an agent read the game state directly instead of inferring it from screenshots, which makes every later debugging task cheaper. Add it at T3.1 if using their template, or T4.1 otherwise.

## Two licensing traps

**Strudel audio is AGPL-3.0.** Their audio module uses it, and AGPL propagates — a game using it must be licensed compatibly. That is fine for a jam entry or an open-source project and a serious problem if the user ever wants to sell it. Raise this at **T8.5** before any audio work, not after.

**Play.fun monetisation is wired in by default** in their pipeline. If the user hasn't asked for monetisation, ensure the SDK isn't present.

## Do not fork it

Do not copy game-creator's contents into this plugin. It is actively developed, so a copy goes stale quickly, and two divergent copies of the same architecture guidance is the exact failure mode T0.3 exists to prevent. Reference it in place and let it update independently.

## If game-creator is not installed

Nothing here is required. The process works without it — these are accelerators, not dependencies. Do not block a task waiting for it.

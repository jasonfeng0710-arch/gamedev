# Performance Checklist

Run at P10. Verify the current numbers against live sources before treating any threshold here as authoritative — renderer defaults, compression formats and browser support shift, and stale budgets are worse than no budgets.

## Measure first

Never optimise before profiling. Establish the baseline:

- `renderer.info` for draw calls, triangles, and allocated geometries/textures
- A stats overlay for frame timing
- Browser devtools performance profile for where the frame actually goes
- A WebGL frame capture extension when the cause isn't obvious

Record the numbers in GAME-PROGRESS.md before and after each fix. Optimisation without measurement is superstition.

## The dominant cost is draw calls

Each Mesh in the scene is one draw call per frame. On mobile GPUs each costs roughly 0.1ms of CPU time, so a few hundred separate objects can consume the entire ~16.6ms frame budget on overhead alone, before rendering anything. This is why scenes with many individual objects stutter on phones while looking trivial on desktop.

**Fix:** instancing. One `InstancedMesh` renders every copy of a geometry in a single draw call, each instance carrying its own transform. `BatchedMesh` handles the case of differing geometries. Instancing and batching routinely cut draw calls by 90% or more.

Target roughly under 100 draw calls per frame on mobile, under 500 on desktop. Frustum culling is automatic — objects outside the camera don't generate calls.

## Geometry

Reduce segment counts for mobile. Halving the subdivisions on spheres and planes is typically imperceptible on a small screen while cutting vertex shader time substantially. Cut particle counts by half or more.

Use level-of-detail for anything that appears at distance.

## Textures and meshes

Compress both. Use a GPU texture format rather than shipping PNGs, and compress mesh geometry. Keep total texture memory well under the mobile budget — this is a common silent killer.

Downscale aggressively. Generated textures arrive far larger than a game needs, and a retro art direction wants them small anyway.

## Memory

Dispose geometries, materials, textures and render targets whenever objects are removed. Failing to do this is the classic leak-until-crash bug, and it usually only shows up after repeated scene transitions.

Test by cycling between scenes twenty times and watching memory. It should stay flat.

## Lighting and shadows

Shadow mapping is one of the most expensive features available. Bake what you can — lightmaps, ambient occlusion, static shadows. Real-time shadows should be reserved for things that genuinely move.

## Load time

The constraint is playable in about two seconds with no loading screen. That means:

- Ship the minimum needed for the first frame
- Stream everything else in afterwards
- Never block first render on a large asset download
- Measure on a throttled connection, not your own

## Real device test

Desktop numbers predict nothing. Thermal throttling and fill-rate limits only appear on real hardware, and a game that runs at 120fps on a laptop can be unplayable on a mid-range phone after two minutes of heating up.

Play it on an actual phone for at least two minutes. Note whether the framerate holds or degrades — degradation over time is the thermal signature and needs a different fix from a low starting framerate.

## Renderer choice

Three.js has both a long-standing WebGL renderer and a newer WebGPU one, with WebGPU support now broad across major browsers. WebGPU offers better performance for scenes with many draw calls, compute shader support, and more predictable frame timing. WebGL remains the lower-risk choice when you want zero surprises on a deadline. Check current support and stability before switching mid-project — this is not a thing to change in the final week.

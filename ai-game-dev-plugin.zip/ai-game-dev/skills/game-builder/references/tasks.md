# Task Ledger

The complete gated task list for building an AI-assisted browser game. 52 tasks across 11 phases.

**Contents**
- P0 Setup (T0.1–T0.5)
- P1 Concept and scope (T1.1–T1.5)
- P2 Project rules (T2.1–T2.4)
- P3 Vertical slice (T3.1–T3.5)
- P4 Debug panel (T4.1–T4.5)
- P5 Asset pipeline (T5.1–T5.6)
- P6 Editor (T6.1–T6.5)
- P7 Content (T7.1–T7.4)
- P8 Polish (T8.1–T8.6)
- P9 Framing (T9.1–T9.4)
- P10 Performance and ship (T10.1–T10.6)
- P11 Launch (T11.1–T11.5)

Each task has: **Objective** (what changes), **Why now** (why this order), **Evidence** (what the user must confirm before advancing), **Ask** (the alignment question), **Watch for** (the known failure), **Research** (when to search the web).

Tasks marked **HARD GATE** must not be bypassed even in fast mode.

---

## P0 — Setup

### T0.1 Choose the stack and lock the constraints
**Objective:** Commit to Three.js in the browser (or justify an alternative in writing).
**Why now:** Every later decision inherits from this. Three.js is the consensus choice for browser games — no install for players, instant sharing, and the richest agent-skill ecosystem.
**Evidence:** User states the stack and the three hard constraints they're accepting: instant load, no login, works on mobile.
**Ask:** "Is there any reason this needs to be something other than a browser game? A downloadable build changes the whole plan."
**Watch for:** Choosing Unity/Godot out of familiarity, then losing days to WebGL export problems.
**Research:** If the user proposes an alternative engine, search for its current web-export maturity before agreeing.

### T0.2 Repo and a live URL on day one
**Objective:** Git repo initialised, hosting connected, a hello-world page deployed to a real URL.
**Why now:** Deploying is the step people postpone and then panic over. Doing it while the project is empty means it can never block a deadline.
**Evidence:** A working public URL the user can open on their phone.
**Ask:** "Paste me the URL — I want to confirm it loads on mobile, not just desktop."
**Watch for:** Deferring hosting to the end. Also: no `.gitignore`, so `node_modules` gets committed.
**Research:** Check current free-tier limits for the chosen host if the user is unsure.

### T0.3 Install exactly one game-dev skill, and scope what you use from it
**Objective:** One Three.js game skill installed in Claude Code, with its orchestration features explicitly ruled out.
**Why now:** These packs inject Three.js knowledge and enforce an architecture. Without one, generated code drifts.
**Evidence:** User names the skill installed, confirms it loads, and states which parts they will and won't use.

**Ask:** "Which one did you install? If more than one, remove all but one — they enforce conflicting architectures and will fight."

**Then ask the scoping question:** "Does it ship autonomous orchestration — one-shot pipelines, self-directing agents, or its own multi-session state file? If so, we use its reference skills and ignore its orchestrator."

This matters more than it sounds. The mature game-dev packs have grown into full pipelines that scaffold, generate art, add audio, deploy and monetise with no user confirmation between steps, plus QA subagents that autofix. That is the exact opposite of this process. Running one hands the user a finished game they made no decisions about, which defeats the point of the whole ledger.

**Use:** the passively-loaded reference skills — Three.js patterns, architecture, visual polish, QA, deploy. These are knowledge, not workflow. They feed plan mode and reinforce the rules file.

**Don't use:** one-shot game commands, autonomous game agents, or any competing state file. If the pack maintains its own multi-session state document, `GAME-PROGRESS.md` remains the single source of truth — running both produces two ledgers that disagree.

**Watch for:** Installing three packs because more sounds better. Also: assuming the whole pack is safe to invoke because the reference skills are good.

**Also check licences here.** Bundled audio or asset libraries sometimes carry copyleft terms that propagate to the game, and bundled monetisation SDKs are often on by default. Both are cheap to opt out of now and expensive to unpick later.

**Research:** Verify the current state of the candidate repos before recommending — commit activity, open issues, and stars all matter, and these packs change scope substantially between versions. What a pack did six months ago is not what it does now.

### T0.4 Asset accounts, licences read
**Objective:** Accounts open for image generation, image-to-3D, and audio. Licence terms actually read.
**Why now:** Free tiers on 3D tools commonly licence your output publicly and forbid commercial use. Finding out after you've built a game around those models is expensive.
**Evidence:** User confirms, for each tool, whether their tier permits the use they intend.
**Ask:** "On the 3D tool's free tier, are your generated models private and commercially usable, or public and CC-licensed? Check before we generate anything."
**Watch for:** Assuming free means unrestricted.
**Research:** Always verify current pricing and licence tiers live. Third-party price trackers frequently disagree with vendor pages — trust the vendor page.

### T0.5 Create GAME-PROGRESS.md
**Objective:** The shared state file exists at repo root and is committed.
**Why now:** This is how the mentor and builder halves stay in sync.
**Evidence:** File exists with the project name, stack, scope decision slot, and task ledger status.
**Ask:** None — just do it and show them.
**Watch for:** Skipping it, then re-explaining the project every session.

---

## P1 — Concept and scope

### T1.1 The core loop in one sentence
**Objective:** One sentence, three beats maximum, describing what the player repeatedly does.
**Why now:** If it can't be said in a sentence, it can't be built in a fortnight.
**Evidence:** The sentence, written down, with each beat being a *different kind* of challenge.
**Ask:** "Say it in one sentence. Then tell me: what does the player do in the first ten seconds, and why would they do it again?"
**Watch for:** A setting instead of a loop. "A game about a haunted forest" is not a core loop.
**Research:** Search for existing games with a similar loop. Not to discourage — to find what they got right and where they're weak.

### T1.2 Pressure-test the concept against AI's strengths **HARD GATE**
**Objective:** Confirm the concept plays to what AI does well, not what it does badly.
**Why now:** Concept choice determines whether the tooling helps or fights you all fortnight.
**Evidence:** A written answer to: which parts does AI make cheap, and which parts will be manual?
**Ask:** "What's the part of this that AI makes possible or cheap? And what's the part you'll have to hand-build regardless?"
**Watch for:** Concepts that need lots of handcrafted level content with no tunable mechanic — those are the slowest path.
**Research:** Look at what recent jam winners chose and why. Patterns worth surfacing: a tunable physics feel is cheap and endlessly adjustable; generated content that couldn't exist otherwise (procedural panoramas, infinite variation) is a strong hook; one mechanic in a contained space beats a sprawling world.

### T1.3 Declare scope
**Objective:** Weekend vertical slice, or full multi-week build.
**Why now:** Scope creep is the most common failure mode in this kind of project.
**Evidence:** An explicit choice, plus a written list of what is deliberately excluded.
**Ask:** "I recommend a weekend slice first — one mechanic, empty box, playable. If moving around isn't fun on its own, no amount of world-building fixes it. Do you want to take that route, or go straight to the full build?"
**Watch for:** "Full build" chosen without the user having ever shipped a game. Recommend the slice, record the override, move on.

### T1.4 Art direction from a variation sheet
**Objective:** A chosen visual style, backed by generated reference images.
**Why now:** Style chosen early and enforced is what makes assets look like they belong together.
**Evidence:** A saved reference image or sheet, plus the style named in one phrase.
**Ask:** "Ask the image model for a *sheet* of variations — style, shape, character design — not one image. Which one did you land on, and can you name the style in three words?"
**Watch for:** Choosing photorealism. Retro-limited styles (low-res textures, limited colour depth, reduced resolution) hide the flaws in AI-generated assets; realism exposes every one.
**Research:** Search for technique articles on reproducing the chosen style in Three.js before implementation.

### T1.5 Write the five-second hook
**Objective:** One sentence describing what a five-second clip of this game shows.
**Why now:** If there's no readable hook, nobody plays it and no judge remembers it.
**Evidence:** The sentence.
**Ask:** "Describe the five-second clip you'd post. If you can't, the concept needs another pass."

---

## P2 — Project rules

### T2.1 Draft CLAUDE.md
**Objective:** A project rules file at repo root.
**Why now:** This is read at the start of every session. Without it, 20k+ AI-written lines become unmaintainable within two weeks.
**Evidence:** File committed, containing: what the project is, hard constraints, architecture, conventions, performance rules, working style.
**Ask:** "Anything about how you want to work that I should encode? Interview-before-implement, plan-to-file, small increments?"
**Watch for:** A vague rules file. Specific and concise beats long and hedged.

### T2.2 Encode the architecture
**Objective:** Folder structure declared and enforced in the rules file.
**Why now:** Structure imposed up front is cheap; imposed later it's a rewrite.
**Evidence:** Folders listed, with a stated rule for cross-module communication (event bus, no direct entity-to-entity imports) and a state object with a clean `reset()`.
**Watch for:** Letting the agent invent structure per feature.

### T2.3 Encode the constraints
**Objective:** Performance and platform rules written into CLAUDE.md.
**Why now:** These need to shape code as it's written, not be retrofitted in week three.
**Evidence:** Rules present for: no magic numbers in gameplay code, instancing for repeated objects, disposal of GPU resources, draw call budget, texture and mesh compression.
**Research:** Verify current Three.js performance guidance rather than relying on memory — renderer defaults and compression formats shift.

### T2.4 Commit and confirm the agent reads it
**Objective:** Prove the rules are actually in effect.
**Evidence:** Ask the agent in a fresh session to state the project's hard constraints. It should answer from the file.
**Ask:** "Start a fresh session and ask it what the constraints are. What did it say?"
**Watch for:** A rules file that exists but is never loaded because it's in the wrong place.

---

## P3 — Vertical slice

### T3.1 Sandbox scene
**Objective:** Flat plane, placeholder player (a cube is fine), running in the browser.
**Why now:** Everything else is tested against this.
**Evidence:** It renders at a local URL.
**Watch for:** Building the real character model first. Placeholder now, art later.

### T3.2 Controls
**Objective:** The player moves under input.
**Evidence:** User confirms they can move it.
**Ask:** "Keyboard only, or does this need touch controls too? If it's meant to work on mobile, we do touch now, not later."

### T3.3 Camera
**Objective:** A camera that follows and feels good.
**Why now:** Camera is half of how a game feels and is usually undertuned.
**Evidence:** User confirms the camera doesn't fight them.
**Watch for:** Rigid camera lock. Damping, lookahead and a little lag are what make it feel alive.

### T3.4 Collision
**Objective:** The player can't pass through things.
**Evidence:** Confirmed against a test obstacle.
**Research:** If the game needs real physics, check the current recommended browser physics engine before committing.

### T3.5 Is it fun in an empty box? **HARD GATE**
**Objective:** Honest verdict on whether the core movement is enjoyable with no content around it.
**Why now:** This is the cheapest possible moment to discover the concept doesn't work.
**Evidence:** The user has played it for at least five minutes and says yes.
**Ask:** "Play it for five minutes with nothing else in the scene. Did you enjoy it, or were you waiting for something to happen? Be honest — this is the cheapest place to change course."
**Watch for:** Talking yourself into a yes because you've already invested two days. If the answer is no, go back to T1.1. That is a success, not a failure.

---

## P4 — Debug panel

### T4.1 Extract constants
**Objective:** Every tunable value moved to a single constants module.
**Why now:** Nothing can be exposed as a slider until it lives in one place.
**Evidence:** No magic numbers remain in gameplay code.

### T4.2 Build the panel
**Objective:** A GUI exposing every constant as a live slider or input, applying without reload.
**Why now:** This is the single highest-return task in the whole process. It's the difference between tuning your game and negotiating with a language model about your game.
**Evidence:** User changes a value and sees it take effect immediately.
**Ask:** "Change the player speed with a slider and confirm it applies without a reload. Does it?"
**Watch for:** A panel that requires a page refresh — that defeats the purpose.

### T4.3 Save and load
**Objective:** Tuned values persist to and load from JSON.
**Why now:** Without this, every refresh loses your tuning and the panel becomes a toy.
**Evidence:** User tunes, saves, reloads, and the values survive.

### T4.4 Encode the rule
**Objective:** CLAUDE.md updated so every new tunable value must be registered in the panel.
**Evidence:** The rule is in the file.

### T4.5 Tune the movement
**Objective:** Spend real time with the sliders making it feel right.
**Why now:** This is the work AI can't do for you.
**Evidence:** User confirms the feel improved and saves the config.
**Ask:** "Spend twenty minutes on the sliders. What did you change, and does it feel better?"

---

## P5 — Asset pipeline

### T5.1 Concept sheet
**Objective:** Generated variations of the main character or hero asset.
**Evidence:** A chosen design.
**Watch for:** Accepting the first generation.

### T5.2 Multi-angle turnaround **HARD GATE**
**Objective:** The chosen design rendered from at least three angles — front, back, and side.
**Why now:** This is the step people skip and it's the one that determines 3D quality. More angles means less guessing by the 3D generator.
**Evidence:** Three or more consistent angle images.
**Ask:** "How many angles do you have? If it's one, the 3D model will be invented rather than reconstructed and we'll waste credits."

### T5.3 First 3D generation, checked in-engine
**Objective:** A textured mesh imported and viewed inside the actual game, not just the tool's preview.
**Why now:** Models that look fine in a preview routinely fall apart in-engine.
**Evidence:** Screenshot or confirmation from inside the game.
**Watch for:** Judging quality in the generator's viewer.

### T5.4 Texture set
**Objective:** Textures generated for every surface material the game needs, downscaled to target resolution.
**Evidence:** Applied in-engine.
**Watch for:** Full-resolution textures blowing the mobile memory budget.

### T5.5 Animation without rigging
**Objective:** Movement on the model without a skeletal rig, if a rig isn't feasible.
**Why now:** Rigging generated meshes is often the hardest step; part-level animation is usually good enough.
**Evidence:** Something moves — wheels turn, head tracks, idle vibration.
**Research:** Check current auto-rigging support in the chosen 3D tool before deciding to skip rigging.

### T5.6 Asset budget check
**Objective:** An honest count of credits burned versus assets accepted.
**Why now:** Retries are the hidden cost. A single stubborn model can take twenty-plus generations.
**Evidence:** A number, and a decision about whether to change approach.
**Ask:** "How many generations have you burned, and how many models do you actually have? If the ratio is bad, we simplify the art direction rather than keep paying."

---

## P6 — Editor

### T6.1 Decide whether you need one
**Objective:** An explicit yes/no on building an internal editor.
**Why now:** Building tools is the biggest multiplier in this process, but not every game needs a level editor. A single-arena game may not.
**Evidence:** A decision plus reasoning.
**Ask:** "What content does this game need that AI generates badly? If the answer is 'a lot', we build you an instrument. If it's 'none', we skip this phase entirely."
**Watch for:** Both errors — building an editor for a game that doesn't need one, and grinding out content by hand for a game that does.

### T6.2 Editor skeleton behind a URL flag
**Objective:** An editor mode reachable only via a query parameter such as `?editor`.
**Why now:** It must never ship to players.
**Evidence:** Editor opens with the flag, is absent without it.

### T6.3 Split editor code from game code **HARD GATE**
**Objective:** The editor lives in its own module tree.
**Why now:** Without the split, the agent updating the game will wipe editor state and destroy your work. This has happened to people repeatedly.
**Evidence:** Separate directory, and a rule in CLAUDE.md forbidding cross-modification.
**Ask:** "Is the editor in its own folder with its own entry point? If it shares files with the game, we fix that before you build any content."

### T6.4 Undo, save, load **HARD GATE**
**Objective:** Ctrl+Z, plus persistence of everything the editor produces.
**Why now:** Content built without undo is content you will eventually lose. Do this before you place a single object.
**Evidence:** User undoes an action and saves a file.
**Watch for:** Postponing undo. It's the most commonly regretted omission in this entire process.

### T6.5 Domain tools
**Objective:** The specific instruments this game needs — terrain brushes, procedural roads or paths, object placement, whatever the content demands.
**Evidence:** User places content with them successfully.
**Watch for:** Polishing the editor's UI. Ugly and working beats pretty and late — floating windows are fine.

---

## P7 — Content

### T7.1 Landmark anchor
**Objective:** One thing visible from everywhere that orients the player and gives the space identity.
**Why now:** Orientation is what makes a space feel like a place.
**Evidence:** It exists and is visible from the far edge.

### T7.2 First playable area
**Objective:** Enough content for one complete run of the core loop.
**Evidence:** User completes the loop start to finish.
**Ask:** "Can you play one full loop — start, middle, end — without leaving the area? If not, what's missing?"

### T7.3 Parallel session work
**Objective:** Use idle agent capacity on an independent feature while you build content manually.
**Why now:** Manual content building leaves the agent idle. Weather, day/night cycles and particle systems are self-contained and safe to run in parallel.
**Evidence:** Something shipped that you didn't have to supervise closely.
**Ask:** "You're going to be in the editor for hours. What independent feature should a second session build meanwhile?"

### T7.4 Content complete
**Objective:** Enough content that the game reads as finished at its declared scope.
**Evidence:** User says stop.
**Watch for:** Never saying stop. Set a deadline for this phase in advance.

---

## P8 — Polish

### T8.1 Real materials
**Objective:** Every placeholder material replaced.
**Why now:** This is typically the single largest visual jump in the whole project.
**Evidence:** Before/after screenshots.

### T8.2 Fog
**Objective:** Distance fog tuned.
**Why now:** Cheap, and it amplifies the sense of scale more than almost anything else.
**Evidence:** Applied and tuned via the debug panel.

### T8.3 Sky
**Objective:** A sky treatment beyond a flat colour.
**Evidence:** Applied.

### T8.4 Lighting and camera perspective
**Objective:** A deliberate lighting pass and a reconsidered camera angle for each distinct scene.
**Why now:** Camera perspective changes are frequently the thing that turns a scene from flat to atmospheric.
**Evidence:** User confirms the scene reads better.

### T8.5 Sound **HARD GATE**
**Objective:** Sound effects on every significant player action, plus music.
**Why now:** Sound is the most underrated multiplier in a short game. Add it before adding another feature.
**Evidence:** Playing with sound on feels different from playing with it off.
**Ask:** "Play it muted, then unmuted. How big is the gap? If it's small, the sound design needs more work."

### T8.6 Juice
**Objective:** Screen shake, particles, trails, scene transitions.
**Evidence:** Applied and tuned.
**Watch for:** Overdoing it. Tune via sliders, not prompts.

---

## P9 — Framing

### T9.1 Diegetic UI
**Objective:** In-world interface rather than floating HUD elements, where it suits the concept.
**Why now:** In-world UI is memorable in a way that overlay text isn't, and models are surprisingly good at generating polished interface layers in CSS.
**Evidence:** It exists and fits the world.
**Watch for:** Forcing this on a game that doesn't want it.

### T9.2 Intro or cutscene
**Objective:** Something that frames the game before play begins.
**Why now:** This is disproportionately what makes a jam game feel like a real product.
**Evidence:** It plays on load without delaying playability.
**Watch for:** Violating the instant-load constraint. The intro must be skippable and must not gate the first frame.

### T9.3 Menu
**Objective:** A menu that reuses cinematic camera positions rather than inventing new ones.
**Why now:** Near-zero extra work for a professional result.
**Evidence:** Menu exists and looks composed.

### T9.4 Localisation
**Objective:** At least two additional languages.
**Why now:** Cheap, and it widens the audience enormously.
**Evidence:** Language switching works.
**Ask:** "Which languages can you personally verify? For the rest, we should have a second pass validate rather than trusting the first translation."

---

## P10 — Performance and ship

### T10.1 Draw call audit **HARD GATE**
**Objective:** Measure draw calls per frame and bring them within budget.
**Why now:** Draw calls, not triangle counts, are what kill browser games on mobile. Each mesh is one draw call per frame, and on mobile each costs roughly 0.1ms of CPU — a few hundred objects can consume the entire frame budget before anything renders.
**Evidence:** A measured number, under roughly 100 on mobile and 500 on desktop.
**Ask:** "What's your actual draw call count? Measure it — don't estimate."
**Research:** Verify current budget guidance and the recommended batching approach before optimising.

### T10.2 Compression
**Objective:** Geometry and textures compressed.
**Evidence:** Total download size measured and stated.

### T10.3 Disposal audit
**Objective:** GPU resources released when objects are removed.
**Why now:** The classic leak-until-crash bug in browser 3D.
**Evidence:** Memory stays flat across repeated scene transitions.

### T10.4 Test on a real phone **HARD GATE**
**Objective:** Play the game on an actual mid-range mobile device.
**Why now:** Desktop performance tells you nothing. Thermal throttling and fill-rate limits only appear on real hardware.
**Evidence:** User played it on their phone and reports the framerate honestly.
**Ask:** "Open it on your phone and play for two minutes. Does it stay smooth, or does it get hot and stutter?"

### T10.5 Instant load
**Objective:** Playable within about two seconds, no loading screen.
**Evidence:** Timed on a normal connection.
**Watch for:** Large uncompressed assets loading before first frame. Stream them in after.

### T10.6 Multiplayer (optional)
**Objective:** If the concept wants it, a minimal relay.
**Why now:** Simpler than people expect for a small game — a single lobby over websockets, clients broadcasting position several times a second, server relaying.
**Evidence:** Two clients see each other.
**Watch for:** Bandwidth scaling with the square of player count. Keep cosmetic systems client-side only.
**Research:** Check current pricing and connection limits on the chosen realtime platform.

---

## P11 — Launch

### T11.1 Thumbnail
**Objective:** A generated key image.
**Evidence:** It exists and represents the game accurately.
**Watch for:** Generators mangling background details. Expect several iterations.

### T11.2 Gameplay clip
**Objective:** A short recording showing the five-second hook from T1.5.
**Evidence:** The clip exists and the hook is visible in the first three seconds.

### T11.3 Deploy to its own domain
**Objective:** A real URL, not a preview link.
**Evidence:** It resolves.

### T11.4 Ship to five people **HARD GATE**
**Objective:** Five humans who aren't you play it and report back.
**Why now:** You cannot see your own game any more. Fresh players find the thing you stopped noticing in week one.
**Evidence:** Five sets of feedback, written down.
**Ask:** "What did all five struggle with? If more than one person hit the same wall, that's the next thing to fix — not the feature you wanted to add."

### T11.5 Retrospective
**Objective:** Written notes on what worked, what wasted time, and what you'd do differently.
**Why now:** The compounding value of this process is in the second project, not the first.
**Evidence:** Notes committed to the repo.
**Ask:** "Where did the time actually go versus where you expected? What tool would have saved you the most, if you'd built it earlier?"

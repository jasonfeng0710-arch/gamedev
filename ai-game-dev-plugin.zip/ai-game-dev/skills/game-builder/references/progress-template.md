# GAME-PROGRESS.md template

Write this to the repo root at T0.5. Both halves of the plugin read and update it. Keep it short — it is a status file, not a journal.

```markdown
# GAME-PROGRESS

## Project
- Name:
- Core loop (one sentence):
- Five-second hook:
- Stack:
- Live URL:
- Art direction:

## Scope
- Declared: [weekend slice | full build]
- Deliberately excluded:
- Deadline (if any):

## Current position
- Phase:
- Current task:
- Blocked on:

## Completed
<!-- one line per task: ID, date, evidence given -->
- T0.1 | 2026-09-07 | Three.js confirmed, three constraints accepted

## Overrides
<!-- any gate the user chose to bypass, and the risk that was stated -->

## Parked
<!-- feature ideas deferred past launch -->

## Decisions
<!-- decisions that would be expensive to revisit, and why they were made -->

## Asset budget
- Generations used:
- Assets accepted:
```

## Rules for maintaining it

Update it at the end of every task, not in batches. The whole value is that a fresh session can read this file and know exactly where things stand without the user re-explaining.

Record evidence in the completed line — "T3.5 | fun confirmed after 8 min play" is useful; "T3.5 | done" is not.

Never delete the overrides section. When a predicted problem arrives, the record is what makes the lesson land.

## Syncing between halves

The chat mentor cannot read the repo. At the start of a chat session, ask the user to paste or upload the current GAME-PROGRESS.md. At the end of the session, output the updated file in full so they can replace it in the repo. In Claude Code the builder reads and writes it directly.

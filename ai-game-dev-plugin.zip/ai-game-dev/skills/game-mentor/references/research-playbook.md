# Research Playbook

The mentor's job includes bringing outside expertise to each decision. Research is not optional colour — it is what separates a mentor from a checklist.

## Always research before

- **Any product claim.** Pricing, free-tier limits, licence terms, model names, library versions, feature availability. These change monthly and training data goes stale. Never quote a price from memory.
- **Any technical budget or threshold.** Draw call limits, texture memory ceilings, triangle budgets, recommended compression formats. Verify against current sources rather than repeating a number.
- **Any "which tool should I use" question.** Check what the field currently recommends, not what was recommended a year ago.
- **The third failed attempt at anything.** Three failures means the approach is wrong, not that the prompt needs rewording. Search for how other people solved that specific problem.

## Research at these specific tasks

| Task | What to look up |
|---|---|
| T0.1 | Web-export maturity if the user proposes a non-browser engine |
| T0.3 | Current state and activity of the candidate game-dev skill repos |
| T0.4 | Live pricing and licence tiers, from vendor pages |
| T1.1 | Existing games with a similar loop — what worked, what's weak |
| T1.2 | Recent jam winners and what concept shapes actually won |
| T1.4 | Technique articles for reproducing the chosen art style |
| T3.4 | Current recommended browser physics engine |
| T5.5 | Auto-rigging support in the chosen 3D tool |
| T10.1 | Current performance budgets and batching techniques |
| T10.6 | Realtime platform pricing and connection limits |

## How to present findings

Lead with the answer, then the evidence. Cite the source. If sources disagree — which happens constantly with tool pricing — say so and name which one to trust and why. Vendor pages beat third-party trackers.

Flag confidence explicitly. If something is a guess, say it is a guess. Fabricating a spec, a price, or a citation is worse than saying "I don't know, check here."

## Bring in expert practice, not just facts

The most useful research finds *how people who are good at this actually work*. Look for:

- Post-mortems and devlogs from people who shipped similar games
- What the judges or the audience actually rewarded
- Techniques that get cited repeatedly by different practitioners
- Known failure modes documented by people who hit them

Prefer primary sources: the developer's own write-up, the official documentation, the organiser's own rules. Aggregator summaries lose the detail that matters.

## Don't over-research

One search for a settled question. Multiple searches for a decision with real stakes. Do not stall the build to research something the user could just try in ten minutes — for anything cheap and reversible, testing beats reading.

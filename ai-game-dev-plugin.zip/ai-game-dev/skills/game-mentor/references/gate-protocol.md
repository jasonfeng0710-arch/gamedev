# Gate Protocol

How to run a single task. This cycle repeats for all 52 tasks.

## The six beats

**1. Orient.** State the task ID, its objective in one sentence, and why it comes now rather than later. Two or three sentences total. The user should always know where they are in the ledger.

**2. Explain the mechanism.** Say what is actually happening technically and why it works. This is a teaching skill — the user is building understanding alongside the game. Not a lecture: two to four sentences, aimed at someone technically literate who isn't a software engineer.

**3. Align.** Ask the task's alignment question. One question. Wait for the answer.

Alignment happens *before* work, not after. The point is to catch a wrong objective while it's still free to change. If the answer reveals a mismatch, resolve it before proceeding — that is the entire purpose of this skill.

**4. Hand over.** Produce the exact prompt to paste into Claude Code, in a copy-ready block. Never write game code in chat. The builder half does that.

**5. Verify.** Ask for the evidence the task requires. Evidence means a URL, a screenshot, a measured number, or a specific yes to a specific question — never "done" on its own.

If evidence is missing, say so plainly and stay on the task. This is the whole point of maximum-rigor mode. Do not advance on an unsupported claim of completion.

**6. Recommend.** Name the next task and why. Update the progress ledger.

## What counts as evidence

| Type | Accept | Reject |
|---|---|---|
| Deployment | A URL that resolves | "It's deployed" |
| Visual | Screenshot or specific description | "Looks good" |
| Performance | A measured number | "Seems fast" |
| Feel | Five minutes played, specific verdict | "I think it's fine" |
| File exists | Pasted content or path confirmed | "I made the file" |

## Hard gates

Tasks marked **HARD GATE** are never bypassed, including in fast mode. They are the points where continuing without confirmation costs days:

- **T1.2** — concept plays to AI's strengths
- **T3.5** — is it fun in an empty box
- **T5.2** — multi-angle turnaround before 3D generation
- **T6.3** — editor split from game code
- **T6.4** — undo exists before content is built
- **T8.5** — sound before more features
- **T10.1** — draw call audit
- **T10.4** — real device test
- **T11.4** — five external players

If a user pushes past a hard gate, say once, plainly, what the specific cost is likely to be. Then record the override in the progress file and continue. Their project, their call — but the record matters, because when the predicted problem arrives they should be able to see it was predicted.

## Fast mode

Invoked by the user saying "fast mode" or similar. Off by default.

In fast mode: batch the remaining non-gate tasks in the current phase into a single handover, collect evidence once at the phase boundary, and skip the mechanism explanation unless asked. Hard gates still run individually and still require evidence. Announce when entering and leaving fast mode.

## When the user is stuck

Do not just re-issue the prompt. Diagnose first:

- **Agent produced broken code** — ask for the error text, then produce a debugging prompt that includes the error rather than a rewrite request.
- **Agent produced working code that's wrong** — the spec was ambiguous. Go back to the alignment question and tighten it.
- **User doesn't understand what they're looking at** — stop and teach. This is a legitimate use of the session.
- **Repeated failure on the same task** — search for how others solved this specific problem before trying a fourth time. Three failures is the signal to research, not to persist.

## Scope pressure

Users add features mid-phase. When it happens, do not simply agree. Ask which of the three:

- It replaces something already planned
- It goes on a parked list for after launch
- It changes the declared scope, which means revisiting T1.3

Record parked items in the progress file. They are usually the second project.

# ai-game-dev

A step-by-step mentor and builder for making an AI-assisted browser game.

Two skills, one shared state file.

| Skill | Runs in | Job |
|---|---|---|
| `game-mentor` | claude.ai chat | Interviews you, researches, critiques, hands you prompts. Never writes game code. |
| `game-builder` | Claude Code | Executes one task in your repo, updates the ledger, stops at the gate. |

They stay in sync through `GAME-PROGRESS.md` at your repo root.

## The process

52 tasks across 11 phases: setup, concept, rules, vertical slice, debug panel,
asset pipeline, editor, content, polish, framing, performance, launch.

Every task runs the same six beats: orient, explain, align, hand over, verify,
recommend. Alignment happens *before* work, so a wrong objective costs a
question rather than a day.

Nine tasks are hard gates and never bypass, including in fast mode:

- T1.2 concept plays to AI's strengths
- T3.5 is it fun in an empty box
- T5.2 multi-angle turnaround before 3D generation
- T6.3 editor split from game code
- T6.4 undo exists before content is built
- T8.5 sound before more features
- T10.1 draw call audit
- T10.4 real device test
- T11.4 five external players

## Install

**Claude Code** — add the plugin directory to your marketplace, or drop the
`skills/` folders into `.claude/skills/` in your project.

**claude.ai chat** — install the `game-mentor.skill` file from the file card
and click Save skill.

## Usage

Start in chat: "I want to make a game." The mentor picks up at T0.1, or reads
your existing GAME-PROGRESS.md and resumes where you left off.

It hands you prompts tagged with task IDs. Paste them into Claude Code, where
the builder recognises the tag and executes that task only.

Say "fast mode" to batch non-gate tasks to phase boundaries. Hard gates still
run individually.
